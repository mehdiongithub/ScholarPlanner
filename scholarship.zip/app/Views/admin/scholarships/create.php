<?php include ROOT_PATH . '/app/Views/layouts/admin_header.php'; ?>

<style>
    .card {
        background: var(--bg-white);
        border: 1px solid var(--border);
        border-radius: var(--radius-2xl);
        padding: clamp(20px, 4vw, 32px);
        box-shadow: var(--shadow-sm);
        margin-bottom: 32px;
    }
    .card-title {
        font-size: 1.25rem;
        font-weight: 700;
        color: var(--text-900);
        margin-bottom: 24px;
        border-bottom: 1px solid var(--border);
        padding-bottom: 12px;
    }
    .form-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }
    .form-group {
        display: flex;
        flex-direction: column;
        gap: 8px;
    }
    .form-group.full-width {
        grid-column: span 2;
    }
    .form-label {
        font-size: 0.875rem;
        font-weight: 600;
        color: var(--text-700);
    }
    .form-control {
        padding: 10px 14px;
        border: 1px solid var(--border);
        border-radius: var(--radius-md);
        font-size: 0.875rem;
        width: 100%;
        background: var(--bg-white);
    }
    .form-control:focus {
        border-color: var(--primary);
        outline: none;
    }
    .checkbox-group {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 12px;
        padding: 8px 0;
    }
    .checkbox-label {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 0.875rem;
        color: var(--text-700);
        cursor: pointer;
    }
    .btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 20px;
        font-size: 0.875rem;
        font-weight: 600;
        border-radius: var(--radius-lg);
        text-decoration: none;
        cursor: pointer;
        border: none;
        transition: all 0.2s;
    }
    .btn-primary {
        background: var(--primary);
        color: var(--bg-white);
    }
    .btn-primary:hover {
        background: var(--primary-dark);
    }
    .btn-secondary {
        background: var(--bg-white);
        color: var(--text-700);
        border: 1px solid var(--border);
    }
    .btn-secondary:hover {
        background: #f1f5f9;
    }
    .btn-danger {
        background: #ef4444;
        color: var(--bg-white);
    }
    .btn-danger:hover {
        background: #dc2626;
    }
    .alert {
        padding: 16px;
        border-radius: var(--radius-lg);
        margin-bottom: 24px;
        font-size: 0.875rem;
    }
    .alert-danger {
        background: #fef2f2;
        color: #991b1b;
        border: 1px solid #fca5a5;
    }
    .dynamic-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 16px;
    }
    .dynamic-table th, .dynamic-table td {
        padding: 8px;
        border: 1px solid var(--border);
        text-align: left;
    }
    .dynamic-table th {
        background: #f8fafc;
        font-size: 0.75rem;
        font-weight: 600;
        color: var(--text-600);
        text-transform: uppercase;
    }
    @media (max-width: 768px) {
        .form-grid {
            grid-template-columns: 1fr;
        }
        .form-group.full-width {
            grid-column: span 1;
        }
    }
</style>

<div style="margin-bottom:24px;">
    <a href="<?= url('/admin/scholarships') ?>" class="btn btn-secondary">
        <i data-lucide="arrow-left"></i>
        <span>Back to List</span>
    </a>
</div>

            <?php
            $errors = $_SESSION['scholarship_errors'] ?? [];
            $old = $_SESSION['scholarship_old'] ?? [];
            unset($_SESSION['scholarship_errors'], $_SESSION['scholarship_old']);
            ?>

            <?php if (!empty($errors['system'])): ?>
                <div class="alert alert-danger" role="alert">
                    <?= e($errors['system']) ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($errors['duplicate'])): ?>
                <div class="alert alert-danger" role="alert">
                    <?= e($errors['duplicate']) ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($errors['csrf'])): ?>
                <div class="alert alert-danger" role="alert">
                    <?= e($errors['csrf']) ?>
                </div>
            <?php endif; ?>

            <form action="<?= url('/admin/scholarships') ?>" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= e($csrf_token ?? '') ?>">

                <!-- Section 1: Basic Information -->
                <div class="card">
                    <h2 class="card-title">1. Basic Information</h2>
                    <div class="form-grid">
                        <div class="form-group full-width">
                            <label class="form-label" for="title">Scholarship Title *</label>
                            <input type="text" id="title" name="title" class="form-control" placeholder="e.g. Erasmus Mundus Joint Master Degree" value="<?= e($old['title'] ?? '') ?>" required>
                            <?php if (!empty($errors['title'])): ?><span style="color:#ef4444; font-size:0.75rem;"><?= e($errors['title']) ?></span><?php endif; ?>
                        </div>
                        <div class="form-group full-width">
                            <label class="form-label" for="cover_image">Scholarship Cover Image</label>
                            <input type="file" id="cover_image" name="cover_image" class="form-control" accept="image/*" onchange="previewImage(event)">
                            <?php if (!empty($errors['cover_image'])): ?><span style="color:#ef4444; font-size:0.75rem;"><?= e($errors['cover_image']) ?></span><?php endif; ?>
                            <div id="imagePreviewContainer" style="margin-top: 12px; position: relative; width: fit-content; display: none;">
                                <img id="imagePreview" src="" style="max-width: 320px; max-height: 180px; border-radius: 8px; border: 1px solid var(--border-slate-200); object-fit: cover;">
                                <button type="button" class="btn btn-danger btn-sm" style="position: absolute; top: 8px; right: 8px; width: auto; padding: 4px 8px;" onclick="removeSelectedImage()">Remove Image</button>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="provider_name">Provider / Organization *</label>
                            <input type="text" id="provider_name" name="provider_name" class="form-control" placeholder="e.g. European Commission" value="<?= e($old['provider_name'] ?? '') ?>" required>
                            <?php if (!empty($errors['provider_name'])): ?><span style="color:#ef4444; font-size:0.75rem;"><?= e($errors['provider_name']) ?></span><?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="provider_type">Provider Type</label>
                            <select id="provider_type" name="provider_type" class="form-control">
                                <option value="">Select Type</option>
                                <option value="government" <?= ($old['provider_type'] ?? '') === 'government' ? 'selected' : '' ?>>Government</option>
                                <option value="university" <?= ($old['provider_type'] ?? '') === 'university' ? 'selected' : '' ?>>University</option>
                                <option value="ngo" <?= ($old['provider_type'] ?? '') === 'ngo' ? 'selected' : '' ?>>NGO / Foundation</option>
                                <option value="private" <?= ($old['provider_type'] ?? '') === 'private' ? 'selected' : '' ?>>Private Corporation</option>
                            </select>
                        </div>
                        <div class="form-group full-width">
                            <label class="form-label" for="short_description">Short Description (Max 500 chars)</label>
                            <input type="text" id="short_description" name="short_description" class="form-control" placeholder="Brief summary of the scholarship benefits and eligibility..." value="<?= e($old['short_description'] ?? '') ?>">
                            <?php if (!empty($errors['short_description'])): ?><span style="color:#ef4444; font-size:0.75rem;"><?= e($errors['short_description']) ?></span><?php endif; ?>
                        </div>
                        <!-- Include Quill stylesheet & library -->
                        <link href="https://cdn.jsdelivr.net/npm/quill@2.0.2/dist/quill.snow.css" rel="stylesheet" />
                        <script src="https://cdn.jsdelivr.net/npm/quill@2.0.2/dist/quill.js"></script>

                        <style>
                            .ql-container {
                                font-family: inherit;
                                font-size: 0.875rem;
                                border-bottom-left-radius: 8px;
                                border-bottom-right-radius: 8px;
                                background: #fff;
                            }
                            .ql-toolbar {
                                border-top-left-radius: 8px;
                                border-top-right-radius: 8px;
                                background: #f8fafc;
                            }
                        </style>

                        <div class="form-group full-width">
                            <label class="form-label" for="description">Full Description * (Supports safe HTML formatting)</label>
                            <textarea id="description" name="description" style="display:none;"><?= e($old['description'] ?? '') ?></textarea>
                            <div id="description-editor" style="height: 300px;"><?= $old['description'] ?? '' ?></div>
                            <?php if (!empty($errors['description'])): ?><span style="color:#ef4444; font-size:0.75rem;"><?= e($errors['description']) ?></span><?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="official_website">Official Website URL</label>
                            <input type="url" id="official_website" name="official_website" class="form-control" placeholder="https://example.com" value="<?= e($old['official_website'] ?? '') ?>">
                            <?php if (!empty($errors['official_website'])): ?><span style="color:#ef4444; font-size:0.75rem;"><?= e($errors['official_website']) ?></span><?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="official_application_url">Official Application URL</label>
                            <input type="url" id="official_application_url" name="official_application_url" class="form-control" placeholder="https://example.com/apply" value="<?= e($old['official_application_url'] ?? '') ?>">
                            <?php if (!empty($errors['official_application_url'])): ?><span style="color:#ef4444; font-size:0.75rem;"><?= e($errors['official_application_url']) ?></span><?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="country_id">Primary Host Country</label>
                            <select id="country_id" name="country_id" class="form-control">
                                <option value="">Select Country</option>
                                <?php foreach ($countries as $c): ?>
                                    <option value="<?= e($c['id']) ?>" <?= ($old['country_id'] ?? '') == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="funding_type">Funding Type</label>
                            <select id="funding_type" name="funding_type" class="form-control">
                                <?php foreach ($fundings as $f): ?>
                                    <option value="<?= e($f['name']) ?>" <?= ($old['funding_type'] ?? '') === $f['name'] ? 'selected' : '' ?>><?= e($f['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Section 2: Study Criteria & normalization -->
                <div class="card">
                    <h2 class="card-title">2. Scope & Target Preferences</h2>
                    <div class="form-group" style="margin-bottom: 20px;">
                        <label class="form-label">Target Degree Levels (Select all that apply)</label>
                        <div class="checkbox-group">
                            <?php foreach ($degrees as $d): ?>
                                <label class="checkbox-label">
                                    <input type="checkbox" name="preferred_degrees[]" value="<?= e($d['name']) ?>" <?= in_array($d['name'], $old['preferred_degrees'] ?? []) ? 'checked' : '' ?>>
                                    <span><?= e($d['name']) ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="form-group" style="margin-bottom: 20px;">
                        <label class="form-label">Disciplines / Fields of Study</label>
                        <div class="checkbox-group">
                            <?php foreach ($fields as $f): ?>
                                <label class="checkbox-label">
                                    <input type="checkbox" name="preferred_fields[]" value="<?= e($f['id']) ?>" <?= in_array($f['id'], $old['preferred_fields'] ?? []) ? 'checked' : '' ?>>
                                    <span><?= e($f['name']) ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="form-group" style="margin-bottom: 20px;">
                        <label class="form-label">Supported Study Countries (Many-to-Many)</label>
                        <div class="checkbox-group">
                            <?php foreach ($countries as $c): ?>
                                <label class="checkbox-label">
                                    <input type="checkbox" name="preferred_countries[]" value="<?= e($c['id']) ?>" <?= in_array($c['id'], $old['preferred_countries'] ?? []) ? 'checked' : '' ?>>
                                    <span><?= e($c['name']) ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="form-group" style="margin-bottom: 20px;">
                        <label class="form-label">Target Provinces / States (Leave empty for all provinces / Pakistan-wide)</label>
                        <div class="checkbox-group">
                            <?php foreach ($states as $st): ?>
                                <label class="checkbox-label">
                                    <input type="checkbox" name="target_states[]" value="<?= e($st['id']) ?>" <?= in_array($st['id'], $old['target_states'] ?? []) ? 'checked' : '' ?>>
                                    <span><?= e($st['name']) ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="form-group" style="margin-bottom: 20px;">
                        <label class="form-label">Target Specific Institutions (Leave empty for all schools/colleges/universities)</label>
                        <div class="checkbox-group" style="max-height: 200px; overflow-y: auto; padding: 10px; border: 1px solid var(--border); border-radius: 6px;">
                            <?php foreach ($institutions as $inst): ?>
                                <label class="checkbox-label" style="margin-bottom: 6px;">
                                    <input type="checkbox" name="target_institutions[]" value="<?= e($inst['id']) ?>" <?= in_array($inst['id'], $old['target_institutions'] ?? []) ? 'checked' : '' ?>>
                                    <span><?= e($inst['name']) ?> <small style="color: #64748b;">(<?= e(ucfirst($inst['institution_type'])) ?>)</small></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Section 3: Eligibility Rules -->
                <div class="card">
                    <h2 class="card-title">3. Eligibility Criteria</h2>
                    <div class="form-grid">
                        <div class="form-group">
                            <label class="form-label" for="minimum_age">Minimum Age</label>
                            <input type="number" id="minimum_age" name="minimum_age" class="form-control" placeholder="e.g. 18" value="<?= e($old['minimum_age'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="maximum_age">Maximum Age</label>
                            <input type="number" id="maximum_age" name="maximum_age" class="form-control" placeholder="e.g. 35" value="<?= e($old['maximum_age'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="minimum_cgpa">Minimum CGPA Required</label>
                            <input type="number" step="0.01" id="minimum_cgpa" name="minimum_cgpa" class="form-control" placeholder="e.g. 3.00" value="<?= e($old['minimum_cgpa'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="cgpa_scale">CGPA Scale</label>
                            <input type="number" step="0.1" id="cgpa_scale" name="cgpa_scale" class="form-control" placeholder="e.g. 4.0" value="<?= e($old['cgpa_scale'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="minimum_percentage">Minimum Percentage (%)</label>
                            <input type="number" step="0.1" id="minimum_percentage" name="minimum_percentage" class="form-control" placeholder="e.g. 75" value="<?= e($old['minimum_percentage'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="gender_requirement">Gender Restriction</label>
                            <select id="gender_requirement" name="gender_requirement" class="form-control">
                                <option value="">No Restriction</option>
                                <option value="male" <?= ($old['gender_requirement'] ?? '') === 'male' ? 'selected' : '' ?>>Male Only</option>
                                <option value="female" <?= ($old['gender_requirement'] ?? '') === 'female' ? 'selected' : '' ?>>Female Only</option>
                            </select>
                        </div>

                        <div class="form-group full-width">
                            <label class="form-label">Eligible Student Nationalities (Leave blank if open to ALL Nationalities)</label>
                            <div class="checkbox-group">
                                <?php foreach ($countries as $c): ?>
                                    <label class="checkbox-label">
                                        <input type="checkbox" name="eligible_nationalities[]" value="<?= e($c['id']) ?>" <?= in_array($c['id'], $old['eligible_nationalities'] ?? []) ? 'checked' : '' ?>>
                                        <span><?= e($c['name']) ?></span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Section 4: Benefits, Documents & Deadlines -->
                <div class="card">
                    <h2 class="card-title">4. Structured Benefits & Deadlines</h2>
                    
                    <h3 style="font-size:0.95rem; font-weight:600; color:var(--text-800); margin-bottom:12px;">Add Benefits</h3>
                    <table class="dynamic-table" id="benefitsTable">
                        <thead>
                            <tr>
                                <th>Benefit Type</th>
                                <th>Brief title</th>
                                <th>Amount</th>
                                <th>Currency</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <select name="benefit_type[]" class="form-control">
                                        <option value="Tuition coverage">Tuition coverage</option>
                                        <option value="Monthly stipend">Monthly stipend</option>
                                        <option value="Annual stipend">Annual stipend</option>
                                        <option value="Accommodation">Accommodation</option>
                                        <option value="Airfare">Airfare</option>
                                        <option value="Visa support">Visa support</option>
                                        <option value="Health insurance">Health insurance</option>
                                        <option value="Books">Books</option>
                                        <option value="Living allowance">Living allowance</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </td>
                                <td><input type="text" name="benefit_title[]" class="form-control" placeholder="e.g. 100% Tuition Fee Waiver"></td>
                                <td><input type="number" step="0.01" name="benefit_amount[]" class="form-control" placeholder="e.g. 15000"></td>
                                <td><input type="text" name="benefit_currency[]" class="form-control" placeholder="e.g. EUR" value="EUR"></td>
                                <td><button type="button" class="btn btn-danger btn-sm" onclick="this.closest('tr').remove();">Remove</button></td>
                            </tr>
                        </tbody>
                    </table>
                    <button type="button" class="btn btn-secondary btn-sm" style="margin-bottom:24px;" onclick="addBenefitRow();">Add Benefit Row</button>

                    <h3 style="font-size:0.95rem; font-weight:600; color:var(--text-800); margin-bottom:12px;">Add Optional Language Test Criteria</h3>
                    <table class="dynamic-table" id="langsTable">
                        <thead>
                            <tr>
                                <th>Test Name</th>
                                <th>Minimum Score</th>
                                <th>Required?</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><input type="text" name="lang_test_name[]" class="form-control" placeholder="e.g. IELTS"></td>
                                <td><input type="text" name="lang_min_score[]" class="form-control" placeholder="e.g. 6.5"></td>
                                <td>
                                    <input type="checkbox" name="lang_is_required[0]" value="1" checked>
                                </td>
                                <td><button type="button" class="btn btn-danger btn-sm" onclick="this.closest('tr').remove();">Remove</button></td>
                            </tr>
                        </tbody>
                    </table>
                    <button type="button" class="btn btn-secondary btn-sm" style="margin-bottom:24px;" onclick="addLangRow();">Add Language Row</button>

                    <div class="form-group" style="margin-bottom: 24px;">
                        <label class="form-label">Required Documents Checklists</label>
                        <div class="checkbox-group">
                            <?php foreach ($documents as $d): ?>
                                <label class="checkbox-label">
                                    <input type="checkbox" name="required_documents[]" value="<?= e($d['id']) ?>" <?= in_array($d['id'], $old['required_documents'] ?? []) ? 'checked' : '' ?>>
                                    <span><?= e($d['name']) ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="form-grid">
                        <div class="form-group">
                            <label class="form-label" for="application_open_date">Opening Date</label>
                            <input type="date" id="application_open_date" name="application_open_date" class="form-control" value="<?= e($old['application_open_date'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="application_deadline">Closing Date</label>
                            <input type="date" id="application_deadline" name="application_deadline" class="form-control" value="<?= e($old['application_deadline'] ?? '') ?>">
                            <?php if (!empty($errors['application_deadline'])): ?><span style="color:#ef4444; font-size:0.75rem;"><?= e($errors['application_deadline']) ?></span><?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="deadline_type">Deadline Type</label>
                            <select id="deadline_type" name="deadline_type" class="form-control">
                                <option value="single" <?= ($old['deadline_type'] ?? '') === 'single' ? 'selected' : '' ?>>Single Fixed Date</option>
                                <option value="rolling" <?= ($old['deadline_type'] ?? '') === 'rolling' ? 'selected' : '' ?>>Rolling Admissions</option>
                                <option value="multiple_rounds" <?= ($old['deadline_type'] ?? '') === 'multiple_rounds' ? 'selected' : '' ?>>Multiple Rounds</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="recurring_interval">Is Recurring?</label>
                            <select id="recurring_interval" name="recurring_interval" class="form-control">
                                <option value="non-recurring" <?= ($old['recurring_interval'] ?? '') === 'non-recurring' ? 'selected' : '' ?>>Non-Recurring</option>
                                <option value="annual" <?= ($old['recurring_interval'] ?? '') === 'annual' ? 'selected' : '' ?>>Annual Recurrence</option>
                                <option value="biannual" <?= ($old['recurring_interval'] ?? '') === 'biannual' ? 'selected' : '' ?>>Biannual Recurrence</option>
                                <option value="monthly" <?= ($old['recurring_interval'] ?? '') === 'monthly' ? 'selected' : '' ?>>Monthly Recurrence</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Section 5: Source Verification -->
                <div class="card">
                    <h2 class="card-title">5. Source Verification Details</h2>
                    <div class="form-grid">
                        <div class="form-group">
                            <label class="form-label" for="source_name">Official Source Name</label>
                            <input type="text" id="source_name" name="source_name" class="form-control" placeholder="e.g. British Council Portal" value="<?= e($old['source_name'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="source_url">Official Source URL Link</label>
                            <input type="url" id="source_url" name="source_url" class="form-control" placeholder="https://example.com/official-page" value="<?= e($old['source_url'] ?? '') ?>">
                            <?php if (!empty($errors['source_url'])): ?><span style="color:#ef4444; font-size:0.75rem;"><?= e($errors['source_url']) ?></span><?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="quality_status">Quality Tier</label>
                            <select id="quality_status" name="quality_status" class="form-control">
                                <option value="good" <?= ($old['quality_status'] ?? '') === 'good' ? 'selected' : '' ?>>Good</option>
                                <option value="excellent" <?= ($old['quality_status'] ?? '') === 'excellent' ? 'selected' : '' ?>>Excellent (Official Government)</option>
                                <option value="poor" <?= ($old['quality_status'] ?? '') === 'poor' ? 'selected' : '' ?>>Needs Review</option>
                            </select>
                        </div>
                        <div class="form-group" style="justify-content: flex-end; padding-bottom: 8px;">
                            <label class="checkbox-label">
                                <input type="checkbox" name="is_featured" value="1" <?= ($old['is_featured'] ?? 0) == 1 ? 'checked' : '' ?>>
                                <strong>Mark as Featured Scholarship</strong>
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Submission Actions -->
                <div style="display:flex; justify-content:flex-end; gap:16px; margin-bottom: 40px;">
                    <a href="<?= url('/admin/scholarships') ?>" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Save as Draft</button>
                </div>
            </form>
        </main>
    </div>

    <script>
        lucide.createIcons();

        function previewImage(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('imagePreview');
                    preview.src = e.target.result;
                    document.getElementById('imagePreviewContainer').style.display = 'block';
                };
                reader.readAsDataURL(file);
            }
        }

        function removeSelectedImage() {
            const fileInput = document.getElementById('cover_image');
            fileInput.value = '';
            document.getElementById('imagePreviewContainer').style.display = 'none';
        }

        function addBenefitRow() {
            const tableBody = document.querySelector('#benefitsTable tbody');
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>
                    <select name="benefit_type[]" class="form-control">
                        <option value="Tuition coverage">Tuition coverage</option>
                        <option value="Monthly stipend">Monthly stipend</option>
                        <option value="Annual stipend">Annual stipend</option>
                        <option value="Accommodation">Accommodation</option>
                        <option value="Airfare">Airfare</option>
                        <option value="Visa support">Visa support</option>
                        <option value="Health insurance">Health insurance</option>
                        <option value="Books">Books</option>
                        <option value="Living allowance">Living allowance</option>
                        <option value="Other">Other</option>
                    </select>
                </td>
                <td><input type="text" name="benefit_title[]" class="form-control" placeholder="e.g. 100% Tuition Fee Waiver"></td>
                <td><input type="number" step="0.01" name="benefit_amount[]" class="form-control" placeholder="e.g. 15000"></td>
                <td><input type="text" name="benefit_currency[]" class="form-control" placeholder="e.g. EUR" value="EUR"></td>
                <td><button type="button" class="btn btn-danger btn-sm" onclick="this.closest('tr').remove();">Remove</button></td>
            `;
            tableBody.appendChild(row);
        }

        let langIndex = 1;
        function addLangRow() {
            const tableBody = document.querySelector('#langsTable tbody');
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><input type="text" name="lang_test_name[]" class="form-control" placeholder="e.g. IELTS"></td>
                <td><input type="text" name="lang_min_score[]" class="form-control" placeholder="e.g. 6.5"></td>
                <td>
                    <input type="checkbox" name="lang_is_required[\${langIndex}]" value="1" checked>
                </td>
                <td><button type="button" class="btn btn-danger btn-sm" onclick="this.closest('tr').remove();">Remove</button></td>
            `;
            tableBody.appendChild(row);
            langIndex++;
        }

        // Initialize Quill editor
        var quill = new Quill('#description-editor', {
            theme: 'snow',
            modules: {
                toolbar: [
                    [{ 'header': [2, 3, false] }],
                    ['bold', 'italic', 'underline'],
                    [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                    ['link', 'clean']
                ]
            }
        });

        // Sync Quill HTML to hidden textarea on form submit
        var form = document.querySelector('form');
        if (form) {
            form.addEventListener('submit', function() {
                var descriptionTextarea = document.getElementById('description');
                if (descriptionTextarea) {
                    descriptionTextarea.value = quill.root.innerHTML;
                }
            });
        }
    </script>
<?php include ROOT_PATH . '/app/Views/layouts/admin_footer.php'; ?>
