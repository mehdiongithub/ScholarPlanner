<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 Page Not Found | ScholarPlanner</title>
    <meta name="robots" content="noindex, nofollow">
    <link rel="icon" type="image/webp" href="<?= asset('assets/images/logo.webp') ?>">
    <link rel="apple-touch-icon" href="<?= asset('assets/images/logo.webp') ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@0.460.0"></script>
    <link rel="stylesheet" href="<?= asset('assets/css/style.css') ?>">
    <style>
        .error-container {
            min-height: 80vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
        }
        .error-card {
            background: var(--bg-white);
            border: 1px solid var(--border);
            border-radius: var(--radius-2xl);
            padding: clamp(32px, 6vw, 48px);
            max-width: 560px;
            width: 100%;
            text-align: center;
            box-shadow: var(--shadow-lg);
        }
        .error-icon {
            width: 64px;
            height: 64px;
            background: #fef2f2;
            color: #dc2626;
            border-radius: var(--radius-lg);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
        }
        .error-icon i {
            width: 32px;
            height: 32px;
        }
        .error-card h1 {
            font-size: 2rem;
            color: var(--text-900);
            margin-bottom: 12px;
            font-weight: 700;
        }
        .error-card p {
            color: var(--text-500);
            font-size: 0.9375rem;
            line-height: 1.6;
            margin: 0 auto 24px;
        }
        .error-actions {
            display: flex;
            justify-content: center;
            gap: 12px;
        }
    </style>
</head>
<body>
    <header class="header scrolled" id="header" role="banner" style="position: relative;">
        <div class="header-inner">
            <a href="<?= url('/') ?>" class="logo" aria-label="ScholarPlanner Home">
                <img src="<?= asset('assets/images/logo.webp') ?>" alt="ScholarPlanner Logo" class="logo-img">
            </a>
        </div>
    </header>

    <main class="error-container">
        <div class="error-card">
            <div class="error-icon">
                <i data-lucide="alert-circle"></i>
            </div>
            <h1>Page Not Found</h1>
            <p>Sorry, the page you are looking for does not exist or has been moved. You can head back to our homepage to search for scholarships.</p>
            <div class="error-actions">
                <a href="<?= url('/') ?>" class="btn btn-primary">
                    <i data-lucide="home" style="width:16px;height:16px"></i>
                    Back to Homepage
                </a>
            </div>
        </div>
    </main>

    <footer class="footer" role="contentinfo" style="padding: 24px 0;">
        <div class="container" style="text-align: center; font-size: 0.75rem; color: var(--text-500);">
            &copy; <?= date('Y') ?> ScholarPlanner. All rights reserved.
        </div>
    </footer>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>
