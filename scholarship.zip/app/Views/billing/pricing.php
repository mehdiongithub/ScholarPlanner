<?php
$title = 'Subscription & Pricing Plans | ScholarPlanner';
$description = 'Affordable plans for students to discover verified international scholarships, get eligibility match alerts, and direct WhatsApp notifications.';
$canonicalUrl = 'https://scholarplanner.com/pricing';
$isStudent = \App\Services\Auth::isAuthenticated() && \App\Services\Auth::currentUser()['role_name'] === 'visitor';

if ($isStudent) {
    include ROOT_PATH . '/app/Views/layouts/student_header.php';
} else {
    include ROOT_PATH . '/app/Views/layouts/public_header.php';
}
?>

<style>
        .pricing-layout {
            min-height: 100vh;
            background: #f8fafc;
            display: flex;
            flex-direction: column;
        }
        .pricing-container {
            max-width: 1000px;
            width: 100%;
            margin: 60px auto;
            padding: 0 20px;
            flex-grow: 1;
        }
        .pricing-header {
            text-align: center;
            margin-bottom: 50px;
        }
        .pricing-header h1 {
            font-size: 2.25rem;
            color: var(--text-900);
            font-weight: 800;
            margin-bottom: 12px;
        }
        .pricing-header p {
            color: var(--text-500);
            font-size: 1.1rem;
        }
        .pricing-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
            margin-bottom: 60px;
        }
        .pricing-card {
            background: var(--bg-white);
            border: 1px solid var(--border);
            border-radius: var(--radius-2xl);
            padding: 40px 32px;
            display: flex;
            flex-direction: column;
            position: relative;
            box-shadow: var(--shadow-sm);
        }
        .pricing-card.premium {
            border: 2px solid var(--primary);
            box-shadow: var(--shadow-md);
        }
        .pricing-card.premium .badge-popular {
            position: absolute;
            top: 20px;
            right: 20px;
            background: #eff6ff;
            color: var(--primary);
            font-size: 0.75rem;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 9999px;
            text-transform: uppercase;
        }
        .plan-name {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--text-900);
            margin-bottom: 8px;
        }
        .plan-desc {
            font-size: 0.875rem;
            color: var(--text-500);
            margin-bottom: 24px;
            min-height: 40px;
        }
        .plan-price {
            display: flex;
            align-items: baseline;
            margin-bottom: 32px;
        }
        .price-num {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--text-900);
        }
        .price-curr {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-500);
            margin-right: 4px;
        }
        .price-interval {
            font-size: 0.875rem;
            color: var(--text-500);
            margin-left: 6px;
        }
        .plan-features {
            list-style: none;
            padding: 0;
            margin: 0 0 40px 0;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            gap: 16px;
        }
        .feature-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            font-size: 0.9375rem;
            color: var(--text-700);
        }
        .feature-item i {
            margin-top: 2px;
            flex-shrink: 0;
        }
        .feature-item.enabled i {
            color: #10b981;
        }
        .feature-item.disabled i {
            color: var(--text-300);
        }
        .feature-item.disabled span {
            color: var(--text-400);
            text-decoration: line-through;
        }
        .pricing-alert {
            background: #fee2e2;
            border: 1px solid #fecaca;
            color: #b91c1c;
            border-radius: var(--radius-lg);
            padding: 16px;
            margin-bottom: 30px;
            font-size: 0.9375rem;
            display: flex;
            align-items: center;
            gap: 12px;
        }
    </style>
</head>
<body>
    <div class="pricing-layout">
        <header class="main-header" role="banner">
            <a href="/" class="logo-box">
                <img src="<?= asset('assets/images/logo.webp') ?>" alt="ScholarPlanner Logo" class="logo-box-img">
            </a>
            <div class="nav-links">
                <a href="<?= url('/scholarships') ?>" class="nav-link">Search Scholarships</a>
                <a href="<?= url('/dashboard') ?>" class="nav-link">Dashboard</a>
            </div>
        </header>

        <main class="pricing-container">
            <div class="pricing-header">
                <h1>Simple, Transparent Pricing</h1>
                <p>Choose the plan that fits your academic journey and scholarship applications.</p>
            </div>

            <?php if (!empty($error)): ?>
                <div class="pricing-alert">
                    <i data-lucide="alert-circle"></i>
                    <span><?= e($error) ?></span>
                </div>
            <?php endif; ?>

            <?php if (!empty($_SESSION['billing_error'])): ?>
                <div class="pricing-alert">
                    <i data-lucide="alert-circle"></i>
                    <span><?= e($_SESSION['billing_error']); unset($_SESSION['billing_error']); ?></span>
                </div>
            <?php endif; ?>

            <div class="pricing-cards">
                <?php 
                $plansList = !empty($plans) ? $plans : \App\Services\Database::connection()->query("SELECT * FROM subscription_plans WHERE status = 'active' ORDER BY price ASC, id ASC")->fetchAll(PDO::FETCH_ASSOC);
                foreach ($plansList as $p): 
                    $isPaid = ((float)$p['price'] > 0);
                    $isCurrent = ($current_plan === $p['slug']);
                    $isPopular = ($p['slug'] === 'premium-monthly' || (count($plansList) > 1 && $isPaid && (float)$p['price'] > 0 && !isset($hasPopularSet)));
                    if ($isPopular) { $hasPopularSet = true; }
                    $intervalText = !empty($p['billing_interval']) ? '/ ' . htmlspecialchars($p['billing_interval']) : '/ month';
                    if (!empty($p['duration_days']) && (int)$p['duration_days'] !== 30) {
                        $intervalText .= ' (' . (int)$p['duration_days'] . ' days)';
                    }
                ?>
                    <div class="pricing-card <?= $isPopular ? 'premium' : '' ?>">
                        <?php if ($isPopular): ?>
                            <span class="badge-popular">Popular</span>
                        <?php endif; ?>
                        <h2 class="plan-name"><?= htmlspecialchars($p['name']) ?></h2>
                        <p class="plan-desc"><?= htmlspecialchars($p['description'] ?: 'Tailored access for student scholarship opportunities.') ?></p>
                        <div class="plan-price">
                            <span class="price-curr"><?= htmlspecialchars($p['currency'] ?? 'PKR') ?></span>
                            <span class="price-num"><?= ((float)$p['price'] == 0) ? '0' : number_format((float)$p['price'], 0) ?></span>
                            <span class="price-interval"><?= $intervalText ?></span>
                        </div>

                        <ul class="plan-features">
                            <li class="feature-item enabled">
                                <i data-lucide="check" style="width:18px;height:18px"></i>
                                <span>Public scholarship discovery & basic search</span>
                            </li>
                            
                            <?php if (!empty($p['max_matches'])): ?>
                                <li class="feature-item enabled">
                                    <i data-lucide="check" style="width:18px;height:18px"></i>
                                    <span>Matching recommendations (Up to <?= (int)$p['max_matches'] ?> matches)</span>
                                </li>
                            <?php else: ?>
                                <li class="feature-item enabled">
                                    <i data-lucide="check" style="width:18px;height:18px"></i>
                                    <span>Personalized matching (Unlimited recommendations)</span>
                                </li>
                            <?php endif; ?>

                            <li class="feature-item <?= $isPaid ? 'enabled' : 'disabled' ?>">
                                <i data-lucide="<?= $isPaid ? 'check' : 'x' ?>" style="width:18px;height:18px"></i>
                                <span><?= $isPaid ? 'Unlimited saved scholarships' : 'Limited saved scholarships (Up to 10)' ?></span>
                            </li>

                            <li class="feature-item <?= $isPaid ? 'enabled' : 'disabled' ?>">
                                <i data-lucide="<?= $isPaid ? 'check' : 'x' ?>" style="width:18px;height:18px"></i>
                                <span><?= $isPaid ? 'Full side-by-side comparison (Up to 4)' : 'Limited side-by-side comparison (Up to 3)' ?></span>
                            </li>

                            <li class="feature-item <?= !empty($p['application_tracking']) ? 'enabled' : 'disabled' ?>">
                                <i data-lucide="<?= !empty($p['application_tracking']) ? 'check' : 'x' ?>" style="width:18px;height:18px"></i>
                                <span>Application workflow tracker</span>
                            </li>

                            <li class="feature-item <?= $isPaid ? 'enabled' : 'disabled' ?>">
                                <i data-lucide="<?= $isPaid ? 'check' : 'x' ?>" style="width:18px;height:18px"></i>
                                <span>Document readiness diagnostics</span>
                            </li>

                            <li class="feature-item <?= (!empty($p['deadline_reminders']) || !empty($p['email_alerts'])) ? 'enabled' : 'disabled' ?>">
                                <i data-lucide="<?= (!empty($p['deadline_reminders']) || !empty($p['email_alerts'])) ? 'check' : 'x' ?>" style="width:18px;height:18px"></i>
                                <span>Email deadline reminders & alerts</span>
                            </li>

                            <li class="feature-item <?= !empty($p['whatsapp_alerts']) ? 'enabled' : 'disabled' ?>">
                                <i data-lucide="<?= !empty($p['whatsapp_alerts']) ? 'check' : 'x' ?>" style="width:18px;height:18px"></i>
                                <span>Direct WhatsApp scholarship alerts</span>
                            </li>
                        </ul>

                        <?php if ($isCurrent): ?>
                            <button class="btn btn-secondary" style="width:100%; justify-content:center; border-color:#10b981; color:#10b981; cursor:default;" disabled>
                                <i data-lucide="check-circle" style="width:16px;height:16px;color:#10b981;"></i>
                                <span><?= $isPaid ? 'Active Subscription' : 'Your Current Plan' ?></span>
                            </button>
                        <?php elseif (!$isPaid): ?>
                            <a href="<?= url('/scholarships') ?>" class="btn btn-secondary" style="width:100%; justify-content:center;">
                                <span>Get Started Free</span>
                            </a>
                        <?php else: ?>
                            <a href="<?= url('/checkout?plan=' . urlencode($p['slug'])) ?>" class="btn <?= $isPopular ? 'btn-primary' : 'btn-secondary' ?>" style="width:100%; justify-content:center;">
                                <span>Upgrade to <?= htmlspecialchars($p['name']) ?></span>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </main>
    </div>

<?php
if ($isStudent) {
    include ROOT_PATH . '/app/Views/layouts/student_footer.php';
} else {
    include ROOT_PATH . '/app/Views/layouts/public_footer.php';
}
?>
