<?php

namespace App\Controllers;

use App\Services\Database;
use App\Services\Auth;
use App\Helpers\Security;
use App\Services\NotificationQueueService;
use PDO;

class NotificationController {
    private PDO $db;

    public function __construct() {
        $this->db = Database::connection();
    }

    /**
     * GET /admin/notifications
     * List outbox alerts with filters
     */
    public function index(): void {
        Auth::requireRole(['admin', 'employee']);
        Auth::requirePermission('notifications.view');

        $status = $_GET['status'] ?? null;
        $channel = $_GET['channel'] ?? null;
        $provider = $_GET['provider'] ?? null;
        $type = $_GET['type'] ?? null;
        $searchUser = $_GET['user'] ?? null;
        $date = $_GET['date'] ?? null;

        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = 15;
        $offset = ($page - 1) * $limit;

        $query = "
            SELECT nl.*, u.first_name, u.last_name, u.email as user_email, s.title as scholarship_title 
            FROM notification_logs nl
            JOIN users u ON nl.user_id = u.id
            LEFT JOIN scholarships s ON nl.scholarship_id = s.id
            WHERE 1=1
        ";
        $params = [];

        if ($status !== null && $status !== '') {
            $query .= " AND nl.status = :status";
            $params['status'] = $status;
        }
        if ($channel !== null && $channel !== '') {
            $query .= " AND nl.channel = :channel";
            $params['channel'] = $channel;
        }
        if ($provider !== null && $provider !== '') {
            $query .= " AND nl.provider = :provider";
            $params['provider'] = $provider;
        }
        if ($type !== null && $type !== '') {
            $query .= " AND nl.notification_type = :type";
            $params['type'] = $type;
        }
        if ($searchUser !== null && $searchUser !== '') {
            $query .= " AND (u.first_name LIKE :user OR u.last_name LIKE :user OR u.email LIKE :user)";
            $params['user'] = '%' . $searchUser . '%';
        }
        if ($date !== null && $date !== '') {
            $query .= " AND DATE(nl.created_at) = :date";
            $params['date'] = $date;
        }

        // Count queries for pagination
        $countQuery = str_replace(
            "SELECT nl.*, u.first_name, u.last_name, u.email as user_email, s.title as scholarship_title",
            "SELECT COUNT(*)",
            $query
        );
        $countStmt = $this->db->prepare($countQuery);
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();
        $totalPages = ceil($total / $limit);

        // Sorting & pagination
        $query .= " ORDER BY nl.created_at DESC LIMIT :limit OFFSET :offset";
        $stmt = $this->db->prepare($query);

        foreach ($params as $key => $val) {
            $stmt->bindValue($key, $val);
        }
        $stmt->bindValue('limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue('offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Summary counts
        $summary = $this->db->query("
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN status='processing' THEN 1 ELSE 0 END) as processing,
                SUM(CASE WHEN status='sent' THEN 1 ELSE 0 END) as sent,
                SUM(CASE WHEN status='delivered' THEN 1 ELSE 0 END) as delivered,
                SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) as failed,
                SUM(CASE WHEN status='retrying' THEN 1 ELSE 0 END) as retrying,
                SUM(CASE WHEN status='skipped' THEN 1 ELSE 0 END) as skipped,
                SUM(CASE WHEN channel='whatsapp' THEN 1 ELSE 0 END) as whatsapp_count,
                SUM(CASE WHEN channel='email' THEN 1 ELSE 0 END) as email_count
            FROM notification_logs
        ")->fetch(PDO::FETCH_ASSOC);

        view('admin.notifications', [
            'logs' => $logs,
            'summary' => $summary,
            'filters' => [
                'status' => $status,
                'channel' => $channel,
                'provider' => $provider,
                'type' => $type,
                'user' => $searchUser,
                'date' => $date
            ],
            'pagination' => [
                'current' => $page,
                'total' => $totalPages,
                'count' => $total
            ]
        ]);
    }

    /**
     * GET /admin/notifications/{id}
     * Inspect individual outbox logs
     */
    public function show(string $id): void {
        Auth::requireRole(['admin', 'employee']);
        Auth::requirePermission('notifications.view');

        $rawId = decode_id($id);
        if ($rawId === null) {
            if (!headers_sent()) {
                http_response_code(404);
            }
            view('errors.404');
            exit();
        }
        $id = $rawId;

        $stmt = $this->db->prepare("
            SELECT nl.*, u.first_name, u.last_name, u.email as user_email, s.title as scholarship_title 
            FROM notification_logs nl
            JOIN users u ON nl.user_id = u.id
            LEFT JOIN scholarships s ON nl.scholarship_id = s.id
            WHERE nl.id = :id LIMIT 1
        ");
        $stmt->execute(['id' => $id]);
        $log = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$log) {
            http_response_code(404);
            view('errors.404');
            exit();
        }

        // Redact sensitive secrets/OTP codes from payload before rendering
        if (!empty($log['payload'])) {
            $payloadData = json_decode($log['payload'], true);
            if (is_array($payloadData)) {
                $sensitiveKeys = ['otp_code', 'code', 'token', 'token_hash', 'password', 'secret', 'key'];
                array_walk_recursive($payloadData, function(&$value, $key) use ($sensitiveKeys) {
                    if (in_array(strtolower($key), $sensitiveKeys, true)) {
                        $value = '[REDACTED]';
                    }
                });
                $log['payload'] = json_encode($payloadData, JSON_PRETTY_PRINT);
            }
        }

        view('admin.notification_detail', ['log' => $log]);
    }

    /**
     * POST /admin/notifications/{id}/retry
     * Force retry of failed queue messages
     */
    public function retry(string $id): void {
        Auth::requireRole(['admin', 'employee']);
        Auth::requirePermission('notifications.retry');

        $rawId = decode_id($id);
        if ($rawId === null) {
            if (!headers_sent()) {
                http_response_code(404);
            }
            view('errors.404');
            exit();
        }
        $id = $rawId;
        $encId = encode_id($id);

        // CSRF Guard
        $csrf = $_POST['csrf_token'] ?? null;
        if (!Security::verifyCsrfToken($csrf)) {
            $_SESSION['notification_error'] = 'CSRF verification failed. Please try again.';
            if (!headers_sent()) {
                header("Location: " . url("/admin/notifications"));
            }
            exit();
        }

        $queueService = new NotificationQueueService();
        $success = $queueService->retryLog($id);

        if ($success) {
            $_SESSION['notification_success'] = "Notification enqueued for processing successfully.";
        } else {
            $_SESSION['notification_error'] = "Could not retry the notification. The maximum delivery attempts have been reached (3/3), or the notification is not in a retryable status.";
        }

        if (!headers_sent()) {
            header("Location: " . url("/admin/notifications/$encId"));
        }
        exit();
    }

    /**
     * POST /admin/notifications/providers/test
     * Admin health connection test for WACRM or Gmail SMTP
     */
    public function testProvider(): void {
        Auth::requireRole(['admin']);
        Auth::requirePermission('notifications.view');

        $csrf = $_POST['csrf_token'] ?? null;
        if (!Security::verifyCsrfToken($csrf)) {
            $_SESSION['notification_error'] = 'CSRF verification failed. Please try again.';
            header("Location: " . url("/admin/notifications"));
            exit();
        }

        $provider = strtolower(trim($_POST['provider'] ?? ''));
        $testEmail = trim($_POST['test_email'] ?? '');

        if ($provider === 'wacrm') {
            $wacrm = new \App\Services\WhatsApp\WacrmWhatsAppProvider();
            $status = $wacrm->testConnection();
            if ($status === 'CONNECTED') {
                $_SESSION['notification_success'] = "WACRM WhatsApp Provider is CONNECTED and operational.";
            } else {
                $_SESSION['notification_error'] = "WACRM WhatsApp Provider connection failed (Status: NOT CONNECTED). Please verify your WACRM_BASE_URL and WACRM_API_KEY.";
            }
        } elseif ($provider === 'smtp' || $provider === 'gmail') {
            $emailService = new \App\Services\EmailNotificationService();
            $res = $emailService->testConnection();
            if ($res['success']) {
                $_SESSION['notification_success'] = "Gmail SMTP connection, TLS handshake, and SMTP authentication verified successfully (Status: AUTHENTICATED). Zero emails sent.";
            } else {
                $_SESSION['notification_error'] = "Gmail SMTP verification failed: " . ($res['error'] ?? 'Unknown SMTP error');
            }
        } else {
            $_SESSION['notification_error'] = "Invalid provider selected for testing.";
        }

        if (!headers_sent()) {
            header("Location: " . url("/admin/notifications"));
        }
        exit();
    }

    /**
     * POST /api/notifications/wacrm/webhook
     * Webhook ingestion endpoint for external WACRM / Meta WhatsApp delivery status callbacks
     */
    public function wacrmWebhook(): void {
        if (!headers_sent()) {
            header('Content-Type: application/json');
        }

        $rawBody = file_get_contents('php://input');
        $payload = json_decode($rawBody, true);
        if (!$payload && !empty($_POST)) {
            $payload = $_POST;
        }

        if (empty($payload) || !is_array($payload)) {
            if (!headers_sent()) {
                http_response_code(400);
            }
            echo json_encode(['status' => 'error', 'message' => 'Empty or invalid JSON payload']);
            if (defined('TESTING_MODE') && TESTING_MODE) { return; }
            exit();
        }

        $queueService = new NotificationQueueService();
        $processed = 0;
        $results = [];

        // Support both Meta WhatsApp Business API webhook structure and flattened/WACRM payload
        $statusUpdates = [];
        if (!empty($payload['entry']) && is_array($payload['entry'])) {
            foreach ($payload['entry'] as $entry) {
                if (!empty($entry['changes']) && is_array($entry['changes'])) {
                    foreach ($entry['changes'] as $change) {
                        $statuses = $change['value']['statuses'] ?? [];
                        if (is_array($statuses)) {
                            foreach ($statuses as $st) {
                                $statusUpdates[] = [
                                    'message_id' => $st['id'] ?? '',
                                    'status' => $st['status'] ?? '',
                                    'timestamp' => isset($st['timestamp']) ? date('Y-m-d H:i:s', (int)$st['timestamp']) : null,
                                    'error' => isset($st['errors'][0]['message']) ? $st['errors'][0]['message'] : null
                                ];
                            }
                        }
                    }
                }
            }
        } elseif (!empty($payload['statuses']) && is_array($payload['statuses'])) {
            foreach ($payload['statuses'] as $st) {
                $statusUpdates[] = [
                    'message_id' => $st['id'] ?? ($st['message_id'] ?? ''),
                    'status' => $st['status'] ?? '',
                    'timestamp' => $st['timestamp'] ?? null,
                    'error' => $st['error'] ?? null
                ];
            }
        } else {
            // Flattened single callback
            $msgId = $payload['provider_message_id'] ?? ($payload['message_id'] ?? ($payload['id'] ?? ($payload['wamid'] ?? '')));
            $status = $payload['status'] ?? '';
            $timestamp = $payload['timestamp'] ?? ($payload['delivered_at'] ?? null);
            $error = $payload['error'] ?? ($payload['error_message'] ?? null);

            if (!empty($msgId) && !empty($status)) {
                $statusUpdates[] = [
                    'message_id' => $msgId,
                    'status' => $status,
                    'timestamp' => $timestamp,
                    'error' => $error
                ];
            }
        }

        if (empty($statusUpdates)) {
            if (!headers_sent()) {
                http_response_code(422);
            }
            echo json_encode(['status' => 'error', 'message' => 'No valid status records found in payload']);
            if (defined('TESTING_MODE') && TESTING_MODE) { return; }
            exit();
        }

        foreach ($statusUpdates as $update) {
            $msgId = trim((string)$update['message_id']);
            $st = trim((string)$update['status']);
            $ts = $update['timestamp'] ?? null;
            $err = $update['error'] ?? null;

            if ($msgId === '' || $st === '') {
                continue;
            }

            $res = $queueService->recordDeliveryStatus($msgId, $st, $ts, $err);
            $results[] = [
                'message_id' => $msgId,
                'status' => $st,
                'result' => $res
            ];
            if (!empty($res['success'])) {
                $processed++;
            }
        }

        if (!headers_sent()) {
            http_response_code(200);
        }
        echo json_encode([
            'status' => 'success',
            'processed' => $processed,
            'details' => $results
        ]);
        if (defined('TESTING_MODE') && TESTING_MODE) { return; }
        exit();
    }
}
